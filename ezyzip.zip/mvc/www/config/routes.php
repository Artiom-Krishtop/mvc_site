<?php
return array(
  'product/([0-9]+)' => 'product/view/$1',  //action view in productController

  'catalog' => 'catalog/index', // actionIndex in catalogController

  'category/([0-9]+)/page-([0-9]+)' => 'catalog/category/$1/$2',//actionCategory incatalogController

  'category/([0-9]+)' => 'catalog/category/$1', //actionCategory in CatalogController

  'user/register' => 'user/register', //actionRegister in UserController

  '' => 'site/index', //actionIndex in SiteController

);




 ?>
